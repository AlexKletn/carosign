# 02. Зависимости между Rust-проектами

## Логический DAG

```mermaid
flowchart TD
    CORE[biometric-core]
    ENGINE[biometric-engine]
    PERSIST[biometric-persistence]
    EVID[biometric-evidence]
    PROTO[biometric-protocol]
    RUNTIME[biometric-runtime]
    LINUX[biometric-linux]
    IPC[biometric-linux-ipc]
    SDK[biometric-provider-sdk]
    DAEMON[biometricd]
    ENGINE --> CORE
    PERSIST --> CORE
    EVID --> CORE
    RUNTIME --> CORE
    RUNTIME --> ENGINE
    RUNTIME --> PERSIST
    RUNTIME --> EVID
    IPC --> PROTO
    SDK --> PROTO
    LINUX --> CORE
    DAEMON --> RUNTIME
    DAEMON --> LINUX
    DAEMON --> IPC
```

No dependency arrow from the core/runtime to any concrete hardware provider. `biometric-protocol` contains wire types only; mapping `wire ↔ core` belongs to adapter modules (e.g., `biometric-linux-ipc::mapping`, `biometric-provider-sdk::mapping`). This avoids forcing the core into protobuf types.

## Logical ports vs transport

| Domain operation | Port owner | Typical implementation |
|---|---|---|
| `Authorize/Validate/WatchRevocation` | runtime authz | Linux polkit bridge / Veles authority |
| `Discover/ClaimResource/Release` | runtime resource orchestration | Linux broker / Veles resource service |
| `ExecuteProviderCommand` | runtime worker supervisor | private seqpacket link |
| `MutationJournal/Registry` | persistence | redb-backed state store |
| `EvaluateEvidence` | evidence | software report trust / TEE verifier |
| `Time/BootIdentity` | runtime time | CLOCK_BOOTTIME + boot id |
| `SendInteractionEvent` | runtime interaction | D-Bus/UI subscriber / Veles Yav |

## Disallowed dependency examples

- `biometric-core` importing `prost` or `tokio` → prohibited.
- `biometric-runtime` importing Goodix command numbers, libfprint `FpPrint`, or NPU-specific types → prohibited.
- `biometric-persistence` deciding PAM authentication result → prohibited.
- `biometric-provider-sdk` importing `biometricd::authz` → prohibited.
- `biometric-linux` importing Veles `Uzel` → prohibited.
- `biometricd` reading raw fingerprint frames → prohibited by normal operations (diagnostics separate).

## Concurrency boundary

Pure engine transitions are sequential and deterministic. Runtime owns per-operation mailbox, serializes transitions, and initiates effects. Worker supervision, cancellation and resource release happen outside pure engine. A slow or blocked device must not hold a lock covering all operations.

## Facade and re-export policy

- `core::prelude` limited to stable identifiers and request/result domain types; no blanket `pub use *`.
- `runtime::RuntimeHandle` is a narrow handle; composition root constructs `RuntimeBuilder` with required ports.
- `protocol` generated fields are not public Rust semantic traits.
- SDK developers depend on generated wire + convenience wrapper, **never** on core internal source layout.
