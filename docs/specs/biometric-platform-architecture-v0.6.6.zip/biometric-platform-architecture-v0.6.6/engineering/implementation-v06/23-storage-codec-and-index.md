# 23. Exact stable encoding for redb metadata keys and values

This document supplements [10](10-persistence-and-recovery.md) and the authoritative `bio/storage/v1/storage.proto`. Rust object serialization (`bincode`, `serde_json`) is **not** the persistent schema. Core IDs are exactly 16 nonzero bytes.

## Key bytes (no length ambiguity)

| redb table | Key encoding | Length |
|---|---|---:|
| `authenticators` | `AuthenticatorId` | 16 |
| `enrollments` | `EnrollmentId` | 16 |
| `enrollment_index` | `AuthorityId  +  SubjectId  +  AuthenticatorId  +  EnrollmentId` | 64 |
| `mutations` | `MutationId` | 16 |
| `mutation_scope_lock` | `AuthorityId  +  SubjectId  +  AuthenticatorId` | 48 |
| `effect_outbox` | `OperationId  +  transition_index(u64 BE)  +  effect_position(u32 BE)` | 28 |
| `idempotency` | `caller_binding_digest(32)  +  idempotency_key(16)` | 48 |
| `provider_state` | `PackageId  +  AuthenticatorId` | 32 |
| `packages` | normalized reverse-DNS package name in UTF-8/ASCII | 1..128 |
| `template_blobs` | `EnrollmentId  +  generation(u64 BE)` (canonical; mirrored in value and validated) | 24 |

` + ` in the table means raw byte concatenation, **not** a stored delimiter or the 0x7f byte. The ASCII-looking notation here is only for readability. Prefix scans on first 48 bytes of `enrollment_index` provide subject+authenticator list; never scan another subject without authority check.

## Durable value envelope (binary)

```
byte 0..3    ASCII "BIO1" (4 bytes)
byte 4..7    protobuf payload length, u32 little endian
byte 8..N    encoded bio.storage.v1.StoredValue
next 32      SHA-256 digest of the protobuf payload only
```

Total value length must equal `8 + length + 32`. For metadata `length` is 1..65536 bytes; for `template_blobs` `length` is 1..8388608 bytes, enforced only for authenticated encrypted blob values. The public IPC frame limit remains 65536 bytes. Parser verifies magic, exact length, SHA-256, protobuf parsing, `schema_version==1`, required fields and semantic validation. SHA-256 here detects accidental corruption but **does not** authenticate against an attacker who can rewrite the database. Cryptographic anti-rollback and protected metadata integrity require separate trusted anchor policy.

`meta` contains a versioned schema marker and migration state using a separate restricted well-known key, not mistaken for `StoredValue` of enrollment. If schema unknown, refuse mutation and retain bytes.

## Indexed record invariants

- On insert/remove/replace, update `enrollments` and its index in **same redb transaction**.
- Under mutation scope lock, at most one non-terminal MutationId for `(AuthorityId, SubjectId, AuthenticatorId)`. If stale lock exists, enter reconciliation and refuse new mutation.
- `expected_generation` is CAS against exact current EnrollmentRef before provider dispatch and again before Registry commit; conflict after provider changed hardware becomes reconciliation, never silent overwrite.
- Outbox entries for mutation exist in same transaction as `DISPATCH_ARMED` record. Exactly one command ID per mutation. Never duplicate send because status remains ARMED after restart.
- `mutation_scope_lock` is not removed until VerifiedCompleted or IndependentlyConfirmedNoChange and durable terminal phase.
- `provider_state` can be unavailable when package removed; keep metadata and template refs.

## Record validation

For `MutationRecord`, `worker_instance_id`/`command_id` may be empty in `Prepared`, but must be 16B at `DispatchArmed` or later. `provider_observation_digest` 32 bytes only when observation present. `EnrollmentRecord` requires `SubjectRef`, `EnrollmentRef`, supported status and bounded format/opaque ref. `IdempotencyRecord` has fixed 32-byte hashes and 16-byte IDs. Unexpected/incomplete fields → corrupted record. Do not patch/reinterpret silently.

## Durability

No I/O within a redb write transaction except DB operations; obtain `DurableReceipt` only once committed with the backend's strongest documented durability mode. System metadata DB file and filesystem must support required durability; no claim that userspace `fsync` can make noncompliant storage hardware safe. Crash/power-loss tests needed on target filesystem before production qualification.

### Canonical key vs mirrored value identity (v0.6.1 clarification)

For `template_blobs`, the **only redb primary key** is `EnrollmentId[16] || generation.to_be_bytes()[8]` (24 bytes). `StoredValue.template_blob.enrollment_id` and `.generation` are deliberately redundant **identity mirrors**, not a secondary key and not an alternative location of truth. On write, derive both mirrors from the single validated key. On read, reject `CorruptRecord` if `record.enrollment_id != key[0..16]` or `record.generation != u64::from_be_bytes(key[16..24])`. Validate nonzero 16B EnrollmentId and generation >= 1. There must never be a best-effort rewrite, silent fallback, or implicit rekey. The template is decrypted only after validating key, record mirrors and Registry ownership/format binding in the same consistent database snapshot; AAD is reconstructed from that validated binding. A mismatch is storage corruption and prevents matching. Test D-11.

A new generation creates a different 24-byte key. Overwriting the value of an existing key with a different record ID/generation is prohibited. The same invariant applies to every read path including recovery and migration.

### v0.6.2 terminal outcome cross-field constraint

`MutationRecord.terminal_outcome` is `MUTATION_TERMINAL_OUTCOME_UNSPECIFIED` unless `phase == MUTATION_COMPLETED`. Exactly when phase is completed it MUST be `MUTATION_TERMINAL_COMMITTED` or `MUTATION_TERMINAL_NO_CHANGE`. `MUTATION_NO_CHANGE` phase is a pre-cleanup stage, never a safe terminal result. Durable finalization and scope-lock release must be one metadata transaction. Read, replay, migration and public `GetOperation` paths validate both fields; incomplete/contradictory records fail closed. Tests B-01f/B-02f. See [27](27-v062-engine-conflict-resolutions.md).

### v0.6.4 optional-template interpretation

`template_blobs` has the stated canonical schema **if an approved provider uses the optional platform vault**. It is neither the universal enrollment store nor a requirement on hardware-owned templates. Provider-owned TA/chip records may have only an `EnrollmentRecord` with an opaque binding; absence of `template_blobs` is normal. Core may not deserialize biometric-template content. See [29](29-v064-provider-owned-matching.md).

### v0.6.5: canonical plan storage v2

Use `MutationRecord.plan` from `storage.proto` and stable canonical plan digest in [33](33-v065-durable-mutation-plan.md). Its identity/snapshot bytes are stored as versioned protobuf in the `mutations` record, with canonical digest byte construction independent of Protobuf field ordering. `schema_version=2` for new writes. The mutation scope lock is released only after verified durable terminal outcome plus safe cleanup, never by a no-change inference from a missing provider ref. Malformed v1 armed records remain quarantined; no fabricated upgrade.

### v0.6.6 storage schema v3

New mutation records and Registry enrollment records require the custody discriminator, and the selected old target participates in the mutation scope digest; `MutationRecord.target_enrollment` is a checked mirror for REPLACE/REMOVE, not a second source. v2 schema, if encountered, follows the explicit quarantine/migration rules in [34](34-v066-enrollment-command-projection.md).
