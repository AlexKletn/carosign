# 09. Device discovery, resource graph and Linux Hardware Broker

## Identification stages

`PlatformInventory` produces ephemeral `DeviceLocator` and hardware signals (ACPI/DT/USB/HID/udev, etc.). `ProviderResolver` compares trusted installed manifest rules to inventory **without** running arbitrary provider code. Multiple approved candidates require explicit system preference or enter `Ambiguous`; do not choose lexicographically. Active probe may only use profile-approved, safe, non-mutating interactions; otherwise require manual binding.

`AuthenticatorId` remains stable only if verified device identity+binding is stable. Raw `/dev/*` path or chip model is not sufficient identity. On ambiguous replacement, refuse automatic association of old registrations.

## Resource graph

Each provider declares `ResourceSet` with access modes (`Exclusive`, `SharedRead`, `Mediated`). Resource Broker policy authorizes package/profile/device binding; manifest declares but does not grant. Scheduler sorts all `ResourceId` bytes lexicographically, requests **entire set atomically**; partial reservation rolls back without any FD transfer. Graph supports shared listeners and exclusive fingerprint controller, but must not incorrectly mark shared QSEE/RPMB resources safe without hardware proof.

### Device states

`Available → Reserved → Active → Quiescing → Available`. On fault: `Uncertain → Recovering → Available | Unavailable`. `WorkerReady` != `DeviceAvailable`. Resource lease `generation` fences stale workers.

## Broker protocol boundaries

Broker implements internal operations `Describe`, `Acquire(resource_set, worker_identity)`, `Delegate(lease, approved_roles)`, `Revoke`, `Release`, `ResetIfSupported`, `GetState`. Each receives platform-validated worker identity, installed policy and exact resource IDs. **No** generic `invoke_any_ioctl` to untrusted provider. Raw QSEE/RPMB handles only to trusted restricted adapter or mediated methods.

### FD rules

- `SCM_RIGHTS` allowed only in Provider `BindAuthenticator`; `fd_slots` explicitly enumerate roles (device, event, sealed config, mediated RPC) and descriptor indices 0..N-1.
- Validate exact descriptor count; close all on mismatch, unknown role, unexpected type. `O_CLOEXEC` on inherited copies except intentionally passed socket; no descriptor leaks.
- A passed FD remains accessible even after broker closes its own copy. **Never claim logical revocation shuts down raw FD use**. If unable to revoke hardware rights, terminate isolated worker and use driver/reset evidence to determine whether device is safe.
- Worker does not get host file paths to arbitrary storage/RPMB. Where needed give scoped service or directory FD with minimal access.

## Linux process sandbox baseline

Dedicated unprivileged UID per approved provider class, no network by default, own mount namespace and only specified device/storage FDs, cgroup CPU/memory/pids limits, seccomp allowlist matched to runtime needs, no ambient capabilities, privilege escalation disabled. For Python/C++/GLib providers relax only specific sandbox calls with review; **never** grant full root because language runtime needs it.

Verified launch: package metadata under root-owned trusted directory, executable opened/validated and bound to spawn without path race where supported; process tracked by pidfd; worker communicates only over inherited private socket. `WorkerHello` self-reported ID does not authenticate package.

## Under-display optical interaction

`InteractionController` owns display illumination + touch capture lease separate from provider worker. Start only after trusted platform has established allowed region and current interaction generation. On cancellation or revoke: release illumination/contact lease, verify quiesce; failure → `Uncertain` resource. Linux may provide untrusted UX path; Veles integrates through Явь. Neither can claim Trusted UI without independently proved barriers.

## Faults

Broker crash: all outstanding privileged leases become Uncertain unless kernel/device independently enforces closure. Provider crash during active verification: suppress outcome + recovery. Provider crash after mutation arm: block enrollment scope + reconciliation. Hot unplug invalidates epoch and owner leases immediately. Suspend/resume requires profile-defined device resume flow; old operations expire, previous proof not reusable.

### Required `ResourceId` binding and FD role resolution (v0.6.1)

Each `FdSlot.resource_id` is the nonzero, 16-byte ID of a specific resource listed in the **currently active** broker-issued lease. The binding tuple is `(lease_id, worker_instance_id, authenticator_id, device_epoch, resource_id, role, handed_fd_identity)`. The broker records this tuple before delivery, including approved handle type and device identity. Provider Manager must verify it atomically with transfer; worker validates `FdSlot` indices/roles and handle shape. `BindAuthenticator` must carry every FD, including broker-mediated socket FDs. No other `bio.provider.v1` packet carries descriptors. Unknown role/resource, duplicate index, unapproved duplicate resource or descriptor mismatch fails binding, closes all received FDs, and never activates the sensor.

Role types: DEVICE=approved device handle identified by broker (do **not** infer authorization from char-device type alone); EVENT=approved Linux eventfd; CONFIG=sealed read-only memfd; MEDIATED_SERVICE=connected Unix `SOCK_SEQPACKET` service channel to broker implementing `bio.broker.v1`. A mediated service is a **revocable RPC authorization**, not a raw QSEE/RPMB FD; every request is checked against current lease and trusted allowlisted handler. `resource_id` is part of the lease and NOT the same as PackageId/ProfileId. ResourcePort provides internal broker-issued claims including these binding tuples; its Rust `acquire` return must be linked to `Delegate(lease, roles)` before Bind. A worker-supplied `resource_id` cannot create authorization. No approved handler for an operation => `UNSUPPORTED`, do not forward arbitrary bytes to a device.

See [25](25-v061-conflict-resolutions.md) and [`bio.broker.v1`](../../contracts/proto/bio/broker/v1/broker.proto).

For mediated calls that may modify persistent TA state, broker reads a trusted `DispatchAuthorizationPort` binding `operation_id+mutation_id+command_id` to durable `DispatchArmed` and current worker/lease/epoch before invoking the handler; worker-supplied IDs do not prove this. Unknown post-dispatch outcome remains `NeedsReconciliation`. See [26](26-mediated-broker-v1.md).

### v0.6.5: broker bulk bodies and credential sink

Delegating `FD_ROLE_MEDIATED_SERVICE` grants access only to already-approved typed handlers. On **that broker socket only**, version 1.1 admits one sealed memfd with `Call`/`CallResult.external_body`; it never changes `BindAuthenticator`-only `SCM_RIGHTS` on provider control. A trusted broker must validate exact FD/worker/lease/resource/epoch/handler identity and body schema before staging into kernel/DMA, and retain hardware memory until safe quiescence. HAT references are resolved and consumed within a separately approved credential-authority sink bound to an armed mutation; a provider receives no HAT bytes or arbitrary access to Gatekeeper. See [31](31-v065-enrollment-authorization.md), [32](32-v065-bulk-command-buffer.md).
