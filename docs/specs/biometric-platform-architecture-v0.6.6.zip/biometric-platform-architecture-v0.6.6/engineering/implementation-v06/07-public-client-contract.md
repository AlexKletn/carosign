# 07. `bio.client.v1`: client-facing service and PAM mapping

**Authoritative schema:** `contracts/proto/bio/client/v1/client.proto` + common. Linux default: public `AF_UNIX/SOCK_SEQPACKET` endpoint `/run/biometricd/control.sock`. Transport access does **not** authorize operations; `SO_PEERCRED` establishes OS peer identity only, and trusted authority checks operation scope separately.

## API surface (v1)

| Request | Who may call | Main response | Notes |
|---|---|---|---|
| `Hello` | any local peer allowed to connect | `HelloAck` | major=1; agree minor, features |
| `ListAuthenticators` | policy-approved observer | descriptors | no private enrollment data |
| `GetAuthenticator` | policy-approved observer | capabilities/health | declared features, not trust proof |
| `ListEnrollments` | subject owner / delegated admin | bounded labels and refs | no template bytes |
| `BeginVerification` | auth consumer authorized for purpose/subject | `OperationAccepted` | `idempotency_key` scoped |
| `BeginEnrollment` | manage-factor grant required | `OperationAccepted` | profile/subject and CAS |
| `BeginRemoval` | manage-factor grant required | `OperationAccepted` | expected generation mandatory |
| `ObserveOperation` | authorized owner/observer | events/snapshot/gap | ID not bearer permission |
| `CancelOperation` | authorized owner/system policy | immediate receipt | receipt != terminal cancellation |
| `GetOperation` | authorized observer | snapshot | bounded and privacy filtered |

Not in v1: public raw images, template export, arbitrary TA commands, `Identify` without claim, secret/key retrieval, remote TCP API, generic device ioctl.

## Verification API semantics

- Client requests `subject_selector`, `authenticator_selector`, `purpose_hint` and opaque `authority_request_ref`. Only trusted authority selects definitive SubjectRef, purpose and grant. If intent conflicts with policy, reject.
- Runtime generates `OperationId`, `BootDeadline`, fresh context and binds to owner. `OperationAccepted` ≠ match.
- Progress: `PlaceFinger`, `MoveFinger`, `RemoveFinger`, `Retry`, `Working`. Standard text is localized **client-side** from event enum; any provider-provided free text treated diagnostic/untrusted, not UI directive.
- External terminal outcome `AcceptedFactor` delivered **only after required evidence acceptance and grant revalidation**, otherwise `NotMatched`, `NoSample`, `Cancelled`, `Unavailable`, `Failed`, `Indeterminate` as appropriate. `AcceptedFactor` means a factor accepted under *that* request, **not** session authorized.
- Evidence token bytes never returned to public client. Trusted authority/KeyMint integration uses a separate restricted port; `EvidenceRef` cannot be replayed for another purpose.

## Idempotency

`idempotency_key`: exactly 16 bytes, nonzero, scope `(authenticated caller binding, subject, operation kind, canonical parameters)`. Runtime stores canonical digest and selected op. Same key and same digest returns existing operation; same key with different digest returns `CONFLICT`. A different key does **not** justify retrying mutating hardware action while same scope is pending. After reboot, verification requests expire; incomplete mutations are discoverable via persisted reference under authority permission.

## Operation ownership and observing

`OwnerHandle` bound to the original authenticated client and grant watcher; `ObserverHandle` separately authorized. `ObserveOperation(after_sequence)` replays existing events within bounded ring; missing history yields explicit `Gap` followed by snapshot. Terminal mutation outcome lives durably and may be acknowledged only by authorized owner; progress is not durable contract. No automatic cancellation on observer disconnect.

For verification, owner death/revocation triggers suppression of success and best-effort cancellation. For mutation, owner death stops new steps, but pending hardware state may require reconciliation and persists independent of client.

## PAM adapter rules

PAM adapter is *client only*, no sensor access. It receives `PAM_USER` and trusted service context, but backend must verify authorization for that subject. Outcomes mapping:

| Accepted factor | `PAM_SUCCESS` only when bound to exact PAM request and policy accepts |
|---|---|
| `NotMatched` | `PAM_AUTH_ERR` |
| `Cancelled`, `Unavailable`, daemon error | `PAM_AUTHINFO_UNAVAIL`, allow configured password fallback |
| Invalid/unknown subject | `PAM_USER_UNKNOWN` |
| `Indeterminate`/invalid evidence | `PAM_AUTHINFO_UNAVAIL`, never success |

Do not ship automatic edits to `/etc/pam.d` during installation; provide example stacks and testing procedure with root recovery path. Keyring secret release is **not** part of `bio.client.v1`; it belongs to separate trusted secret consumer, never implicit `PAM_AUTHTOK` propagation by core.

## Endpoint/resource limits

One frame max 64 KiB. Public peer must complete hello within 5 seconds. Default 4 active/queued operations per connection; max 16 queued per authenticator; default max 8 observers per operation; event ring 128. Implementation must support admin policy for tighter limits and fail with typed `LIMIT_EXCEEDED`, never unbounded queue allocation.
