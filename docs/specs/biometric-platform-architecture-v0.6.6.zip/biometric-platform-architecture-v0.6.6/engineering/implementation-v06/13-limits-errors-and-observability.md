# 13. Bounded execution, error model and observability

## Baseline v1 limits (defaults; security ceilings)

| Parameter | Default | Absolute ceiling in v1 | Failure behavior |
|---|---:|---:|---|
| Protobuf control frame serialized bytes | 65536 | 65536 | close on oversized packet |
| Ancillary FDs per frame | 8 | 8 | close all received FDs, reject |
| Opaque provider enrollment ref bytes | 4096 | 4096 | `INVALID_MESSAGE` |
| Client connections concurrently | 32 | 128 | refuse new connection |
| Active+queued ops per connection | 4 | 16 | `LIMIT_EXCEEDED` |
| Queued ops per authenticator | 16 | 64 | `BUSY` |
| Observers per operation | 8 | 32 | `LIMIT_EXCEEDED` |
| Event history ring per operation | 128 | 1024 | explicit gap + snapshot |
| Worker actor command mailbox | 64 | 256 | backpressure/failure |
| Labels, UTF-8 bytes | 64 | 64 | `INVALID_ARGUMENT` |
| Public free-text error bytes | 256 | 256 | sanitize/truncate without secrets |
| Public Hello deadline | 5 s | 5 s | disconnect |
| Provider Hello/Initialize per phase | 5 s | 5 s | terminate worker |

Verification/enrollment *physical* timeouts cannot be universally fixed without device facts. Baseline policy is verify 30s, enroll 120s **subject to platform policy and device capability**, never unlimited unless explicitly authorized diagnostic mode, which is not public IPC. Cleanup timeout default 10s; expiration leads to quarantine/uncertain, not assumed quiescence. Configuration can tighten limits and may increase only within ceiling with explicit owner review.

## Errors are typed; no opaque `Error(String)` as protocol semantic

| Class | Codes (baseline) | Meaning |
|---|---|---|
| Protocol | `INVALID_MESSAGE`, `UNSUPPORTED_VERSION`, `UNEXPECTED_PHASE`, `FRAME_TOO_LARGE`, `FD_MISMATCH` | transport/schema violation |
| Authorization | `UNAUTHORIZED`, `GRANT_REVOKED`, `SCOPE_MISMATCH`, `SUBJECT_UNKNOWN` | policy boundary |
| Operation | `BUSY`, `UNSUPPORTED`, `UNAVAILABLE`, `TIMEOUT`, `NO_USABLE_SAMPLE`, `CANCEL_REQUESTED` | execution status |
| Persistence | `STORE_UNAVAILABLE`, `CORRUPT_STATE`, `GENERATION_CONFLICT`, `MUTATION_INDETERMINATE`, `RECONCILIATION_REQUIRED` | durable state |
| Evidence | `EVIDENCE_INVALID`, `EVIDENCE_UNVERIFIED`, `RECIPIENT_MISMATCH` | proof checking |
| Infrastructure | `WORKER_LOST`, `RESOURCE_UNCERTAIN`, `DEVICE_REMOVED`, `BROKER_FAILED` | process/device issues |

`NotMatched` is a verification outcome (normal), **not** a protocol/system error. `MutationMayHaveOccurred` cannot be rewritten to `Cancelled`/`NoChange`. Client-facing messages use stable error codes and optional sanitized diagnostic text, not raw stack traces/TA hex buffers.

## Observability and privacy

Structured logs contain timestamp, operation ID (where privacy policy permits), provider instance ID, phase, outcome code and timing bucket. No raw frames, template bytes, key/PSK, token, password, subject display names or full hardware serial. Sensitive diagnostic capture is **separate tool with explicit temporary authorization**, disabled by default and never exported to public UI. Audit event stream has its own retention policy; event hub is not audit log. Telemetry cardinality bounded; no uncontrolled label string values.

## Health vs authorization

`ServiceReady`: daemon listens and safe policy established. `DeviceAvailable`: per-device status. `EvidenceVerified`: only trusted verifier result. Do not confuse one with another. Service may be running while one provider is quarantined. Public health snapshot gives broad reason; privileged diagnostics can inspect details.

## Fault policy

- Invalid packet: fail current connection, preserve global state.
- Worker crash during verification: revoke result, request hardware recovery.
- Worker crash after mutating command armed: durable `NeedsReconciliation`; block affected scope.
- DB corruption: affected scope/entire store unavailable; never initialize empty state silently.
- Authorization/evidence service timeout: fail closed; no trust downgrade.
- No provider installed: healthy service with zero available authenticators.

### Dispatch/metadata error distinction (v0.6.2)

`VerifyDispatchNotSent` means verified locally that the provider command was not dispatched; its internal terminal result is `Failed(DispatchNotSent(reason))`. A service/device/transport outage may map to public `Unavailable`; unsupported operation or denied grant retain their own distinct public errors. `VerifyDispatchUnknown` indicates the command may have been delivered, invalidates any current proof and requires worker/device quiescence or quarantine. Neither becomes `NotMatched`.

`MetadataFailed` after `DispatchArmed` is never a harmless validation failure or `NoChange`; it enters reconciliation. Failure to persist that uncertainty is a *storage availability* fault, requiring an in-memory quarantine until the durable record can be reread. Do not mark durable recovery as successful from an unsuccessful write or an unknown commit ACK.

### v0.6.5 limited bulk and enrollment challenge

`broker.Call/CallResult.external_body` is broker-only protocol minor 1: **one** immutable sealed memfd, 1..8MiB and no more than handler-specific configured maximum; not counted in the <=64KiB serialized control envelope, but counted against bounded broker in-flight memory/FD/resource budgets. Challenge size 1..64B and ref 16B; trusted credential authority controls monotonic expiry. A broker-handler timeout with unknown DMA/TA completion retains ResourceUncertain; an armed mutation retains NeedsReconciliation. Log neither HAT nor challenge secret/token blob, raw hardware body, biometric data or DMA addresses.
