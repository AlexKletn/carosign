# 06. `bio.provider.v1`: process and wire contract

**Authoritative schema:** `contracts/proto/bio/provider/v1/provider.proto` + imported common. This document specifies runtime behavior the schema alone cannot express. Provider may be implemented in C, C++, Go, Rust, Python, etc. The Rust SDK is optional. No stable Rust ABI.

## Transport

- Linux: private `socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC)` created by supervisor. One whole serialized `ProviderFrame` protobuf per datagram/message; no additional four-byte length prefix. Max message **65536 bytes**, including serialized envelope, excluding ancillary data. No implicit fragmentation; larger payloads require negotiated FD transport.
- Provider-control FD passing uses `SCM_RIGHTS` *only* with `BindAuthenticator`. The separate mediated **broker** socket permits a tightly scoped sealed-memfd external body in protocol minor 1; never forward it through the provider-control channel. `fd_slots` matches ancillary descriptor order and exact count, maximum 8 FDs per frame. If count/kind mismatches, close all received FDs and reject frame without hardware side effects. Runtime and broker create FD, not arbitrary worker claims.
- Sequence `frame_seq` starts at 1 per direction and increments by 1. Gaps/duplicates produce protocol fault and close session; worker/epoch values are fenced on every operation frame.
- No public socket address for worker. Established process identity is anchored by supervisor's verified spawn and inherited channel, not text inside WorkerHello.
- Version: major must equal 1; select **highest common** minor between advertised ranges, but **reject any result below 2**: scoped enrollment bindings and challenge authorization require v1.2; minor 0/1 workers cannot execute live operations. `feature` IDs agreed by both; unknown feature IDs ignored only at negotiation, never assumed active. New security semantics require new major/explicit feature.
- Transport bytes are **never** blindly converted to trusted `Grant`/`Assessment`/`DeviceLease`. Runtime adapter validates scopes.

## Handshake and phases

| Phase | Runtime→Worker | Worker→Runtime | Failure |
|---|---|---|---|
| `Starting` | none | `WorkerHello` within 5s | terminate worker |
| `Negotiating` | `Initialize` | `Initialized` within 5s | terminate |
| `Binding` | `BindAuthenticator` with scoped resources | `AuthenticatorReady` within 15s (or profile-approved bounded override) | isolate and close leases |
| `Ready` | `Describe`, `Start*`, `QueryMutation`, `RequestCancel`, `Quiesce` | accepted / progress / terminal | operation-specific recovery |
| `Draining` | `Quiesce`, `CloseAuthenticator`, `Shutdown` | cleanup confirmation | quarantine on uncertain hardware |

Handshake packets outside valid phase are protocol errors. Worker does not open sensors during Hello; first broker-issued hardware access is only after policy-approved `BindAuthenticator`. An `AuthenticatorReady` response never certifies hardware safety by itself: manager still checks broker/assessment state.

## Operation messages

`StartVerification`: targets one resolved subject binding + authenticated `VerificationContext`. An outcome is provider-origin `Matched` (possibly without token, converted to scoped ProviderAssertion by trusted Runtime), `NotMatched`, `NoUsableSample`, `Cancelled` or typed failure. `Matched` is **not** authentication success.

`StartEnrollment`: mutating operation (including trustlet prep that may persist); must carry `MutationId` and prepared context. Worker must not initiate unjournaled persistence. `StartRemoval`: targets `(EnrollmentId, expected_generation, provider_opaque_reference)`; stale generation → reject without deletion.

`QueryMutation`: only safe, non-mutating reconciliation mechanisms, with explicit `Unsupported/ConfirmedPresent/ConfirmedAbsent/Unknown`; must **not** silently create or delete enrollment. If hardware lacks trustworthy query, return `Unknown`.

`RequestCancel`: accepts request anytime operation active; ACK `CancelRequested` is *not* terminal. Final outcome may be `CancelledAndQuiesced`, `Completed`, `MutationMayHaveOccurred`, `CancellationUnsupported`. Last two require reconciler/device recovery rules. Cancellation cannot block behind capture worker; control reader stays responsive.

`Quiesce`: request controlled stop. Device cannot become Available until broker or supported hardware adapter confirms physical safety. Process death alone is insufficient.

## Worker event sequencing

Every event binds current `operation_id`, `device_epoch`, `worker_instance` and increasing `event_sequence` **per operation**. Progress events can be coalesced for public clients; provider→runtime events cannot fabricate terminal success. Exactly one normal terminal `ProviderOutcome` per accepted command. Duplicated terminal → protocol fault; stale epoch → discard/quarantine event, no registry mutation.

`CommandAccepted` only confirms command acceptance, not device dispatch nor durability. If a mutating send was armed before transmission, a missing accepted/outcome is still indeterminate.

## Worker privileges

Manifest describes needs, but a root-owned policy authorizes capabilities. Provider sees only approved FDs/RPC services. No direct root, network or broad `/dev/*` by default. For QSEE, arbitrary TA/raw RPMB access forbidden to untrusted worker; use scoped broker API. For libfprint C/GLib, worker may load its runtime and initialize GLib loop inside sandbox. Provider package does not self-certify assurance.

## Version constraints

Provider protocol v1 must treat unknown enum values affecting operation semantics as invalid; optional unknown fields must not grant rights or change meaning of known fields. Reject unexpected payload for phase, invalid ID size, excessive repeats, unapproved FD slots and unknown result statuses. Wire schema is the only compatibility ABI; Rust SDK must be verified against independent fixture suite.

### Normative FD-slot contract (v0.6.1)

`BindAuthenticator` is the **only** provider-protocol message carrying `SCM_RIGHTS` in current v1.2, including for mediated-service sockets. Each `FdSlot` has `index`, `role`, `resource_id`. Exact ancillary fd count equals `fd_slots` length (0..8), indices form a permutation of `0..N-1` without duplicates, roles are known, resource IDs are nonzero 16B **and must appear in a broker-approved active `ResourceLease` for this worker and current authenticator epoch**. Compare the specific approved fd↔resource binding held by the broker, not merely a provider-provided string. A second slot with same resource ID requires an explicit distinct approved grant; otherwise reject. All failed binds close every received descriptor, report protocol fault and grant no device access. The worker must confirm actual FD shape, and the system validates it against broker-issued handle metadata.

Roles: `FD_ROLE_DEVICE` = specifically delegated approved device handle (not assumed to be only a char-device fd); `FD_ROLE_EVENT` = approved `eventfd` notification handle; `FD_ROLE_CONFIG` = read-only sealed `memfd` carrying bounded versioned configuration; `FD_ROLE_MEDIATED_SERVICE` = connected `AF_UNIX/SOCK_SEQPACKET` socket to **trusted** hardware broker speaking `bio.broker.v1`. Broker validates lease, worker, resource, method allowlist and typed payload for **every call**; no arbitrary ioctl/TA command is exposed. The mediated service is **not** the provider control connection and cannot confer new capabilities. See [09](09-device-and-broker.md), [20](20-protobuf-wire-validation.md), [25](25-v061-conflict-resolutions.md) and `contracts/proto/bio/broker/v1/broker.proto`.

### v0.6.4 — scope-bound verification for all implementation strategies

`StartVerification` now includes a bounded set of authorized `EnrollmentBinding` values. The worker handles matching internally (host, chip, TEE, libfprint) and may return `Matched` with no raw evidence token; Runtime creates a scoped ProviderAssertion instead of pretending a hardware credential exists. Reject unscoped matches; optional `matched_enrollment` must be in the granted binding set. `StartEnrollment` includes the old binding on replace, and `StartRemoval` is scoped to its expected binding. Protocol version 1.2 is required for the current baseline (including challenge authorization); 1.1 describes only the historical scoped-matching revision. See [29](29-v064-provider-owned-matching.md).

### v0.6.5: enrollment challenge and scoped removal (provider 1.2)

`CapabilityDescriptor.enrollment_authorization` MUST be `NONE` or `HAT_CHALLENGE` for an enrolling worker. HAT mode requires `PrepareEnrollmentChallenge → CommandAck → EnrollmentChallengeReady` followed by trusted credential step-up and `StartEnrollment` with the scoped authorization ref plus SHA-256 challenge digest; raw HAT is prohibited in provider control frames. Prep may run before durable arm **only** if the specific pre-enroll path is audited not to persist enrollment state. Details: [31](31-v065-enrollment-authorization.md).

`StartRemoval.enrollment_binding` is REQUIRED in provider minor 2 and must exactly match `enrollment`. When `PROVIDER_OPAQUE`, legacy `provider_opaque_ref` equals its opaque ref, or may be empty to avoid duplication; when `SCOPED_VAULT`, `provider_opaque_ref` MUST be empty. Every active/generation/subject scope is checked by Runtime; no implicit full-database access. `QueryMutationResult` fields are provider hints, **not independently verified hardware reconciliation**. See [33](33-v065-durable-mutation-plan.md).

### Provider protocol v1.3 (v0.6.6 current baseline)

The previous v1.2 wording is historical. Current provider live operations require negotiated **minor >=3**. `StartEnrollment.planned_enrollment` (field 9) is a mandatory system-assigned NEW `EnrollmentRef`, for both create and replace. Exactly one of the internally typed `EnrollmentCommandChange::Create|Replace` alternatives determines whether `replace`/`replace_binding` are absent or both present; the complete checked old binding is supplied to the provider adapter by Runtime's `CommandPlan`. On completed enrollment, `MutationOutcome.enrollment` echoes the planned new ref; echo is not a hardware proof. Full validation and storage v3 semantics in [34](34-v066-enrollment-command-projection.md).
