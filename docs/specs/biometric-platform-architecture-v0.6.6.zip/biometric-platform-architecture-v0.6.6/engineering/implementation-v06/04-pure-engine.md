# 04. `biometric-engine`: deterministic transitions and effects

**No I/O**: engine is a pure state machine. It does not read clocks, files, random numbers or sockets and knows nothing about protobuf. Runtime supplies prevalidated observations, generated IDs, timestamps and authorizations. Engine may reject inconsistent observations; it must not silently accept them.

## Primary interface

```rust
pub struct Decision<S> {
    pub next: S,
    pub effects: Vec<EffectSpec>,
}
pub fn decide(
    state: &OperationState,
    input: DomainInput,
) -> Result<Decision<OperationState>, TransitionError>;
```

`OperationState` is the normative tagged union specified in [28](28-v063-operation-discriminant-and-send.md): common context + `OperationBody::{Verification,Enrollment,Removal}`. Machine-specific phase and mutation plan belong only to the respective variant, never to a `mutation: Option<_>` selector. Every successful transition increments index by exactly 1. `EffectId` derives deterministically from `(OperationId, transition_index, effect_position)` **by a fixed keyed-free hash or explicit tuple persisted in metadata**; choose tuple on disk (`operation_id`, `transition_index`, `effect_position`) to avoid collisions and hidden hashing decisions. Runtime may assign a 16-byte transport `CommandId` when executing typed `EffectSpec::SendVerify` or `EffectSpec::SendMutatingCommand`, and records mapping in outbox.

## State machines stay separate

- `VerificationMachine`: biometric result, evidence check, completion.
- `EnrollmentMachine`: prepare/arm/send/confirm/registry/reconcile.
- `RemovalMachine`: same durable safeguards, generation-sensitive delete.
- `WorkerMachine`: spawn, handshake, bound, ready, draining, fault.
- `DeviceMachine`: resource state, uncertain, recover, unavailable.

The operation machine observes worker/device state via explicit `DomainInput`, **never** by reading another actor's mutable state. A ready worker with uncertain hardware cannot proceed.

## Verification transition table

| Current | Input | Next | Effects |
|---|---|---|---|
| `New` | `Authorized` | `WaitingLease` | `AcquireResources` |
| `WaitingLease` | `LeaseGranted` | `ReadyToDispatch` | `RevalidateGrant` |
| `ReadyToDispatch` | `GrantValid` | `Running` | `SendVerify` |
| `Running` | `ProviderProgress` | `Running` | `PublishProgress` |
| `Running` | `VerifyDispatchNotSent` | `Finalizing` | `RecordVerificationFailure(DispatchNotSent)`, `ReleaseResources` |
| `Running` | `VerifyDispatchUnknown` | `Cancelling` | `SuppressResult`, `RequestCancel`, `QuarantineResourceUntilQuiesced` |
| `Running` | `ProviderNotMatched` | `Finalizing` | `ReleaseResources` |
| `Running` | `ProviderMatched(evidence_ref)` | `EvaluatingEvidence` | `VerifyEvidence` |
| `EvaluatingEvidence` | `EvidenceAccepted` | `Finalizing` | `RevalidateOwner`, then `DeliverAccepted` only after valid |
| `EvaluatingEvidence` | `EvidenceRejected` | `Finalizing` | `DestroyEvidence`, `ReleaseResources` |
| Any nonterminal | `OwnerRevoked/DeadlineExpired` | `Cancelling` | `RequestCancel`, `SuppressResult` |
| `Finalizing` | `CleanupConfirmed` | `Terminal` | `RecordTerminal`, one delivery if authorized |

`ProviderMatched` is **never** a terminal public success. If `OwnerRevoked` races with `EvidenceAccepted`, suppression takes precedence. Any stale epoch or worker instance event is rejected without changing state. `NoUsableSample` and failures enter finalizing with their distinct outcome; no implicit retry without an explicit configured retry policy controlled by Runtime.

## Mutation state machine (Enroll / Remove)

| Current | Input | Next | Effects |
|---|---|---|---|
| `New` | `ManageGrantValid` | `Preparing` | `PersistIntent` |
| `Preparing` | `IntentDurable` | `WaitingLease` | `AcquireResources` |
| `WaitingLease` | `LeaseGranted` | `Preflight` | `RevalidateGrant` |
| `Preflight` | `GrantValid` | `Arming` | `PersistDispatchArmed` |
| `Arming` | `DispatchArmedDurable` | `InFlight` | `SendMutatingCommand` |
| `InFlight` | `ProviderProgress` | `InFlight` | `PublishProgress` |
| `InFlight` | `ProviderCompleted` | `ValidatingChange` | `CheckProviderResult` (and independent query if required) |
| `ValidatingChange` | `ChangeConfirmed` | `Committing` | `CommitRegistryAndJournal` atomically |
| `Committing` | `MetadataDurable` | `Finalizing` | `ReleaseResources` |
| `Finalizing` | `CleanupConfirmed` | `Terminal` | `MarkCompletedAndNotify` |
| `InFlight/ValidatingChange/Committing` | `WorkerLost/Timeout/Unknown` | `Reconciling` | `PersistNeedsReconciliation`, `QuarantineScope` |
| `Reconciling` | `DesiredStateVerified(verified)` | `Committing` | `CommitDesiredRegistryAndJournal(verified)` atomically |
| `Reconciling` | `PreStateVerified(verified)` | `Committing` | `CommitNoChangeAndJournal(verified)` atomically; Registry contents unchanged |
| `Reconciling` | `VerificationIndeterminate` | `Reconciling` | `PersistNeedsReconciliation` if not yet durable; retain scope lock |
| `Committing` | `MetadataFailed` (after arm) | `Reconciling` | `QuarantineScope`, `RecoverMetadataCommit` (no new hardware mutation) |

**Nonnegotiable order:** durable intent before resource-side change; `DispatchArmed` durable before mutating command dispatch; Registry+Journal commit in one metadata transaction. Effects have explicit receipts. If crash occurs after `DispatchArmed`, even before actual send, recovery must conservatively treat hardware as potentially changed. **No automatic retry of mutating send.**

`CancelRequested` before `DispatchArmed` → stop and confirm no dispatch; after arming → request cancel and mark uncertain unless provider independently proves no side effect. `CancelReceived` is only an acknowledgement, not safe cleanup.

## Effects and receipts

| Effect | Confirmation input |
|---|---|
| `PersistIntent` | `IntentDurable` |
| `PersistDispatchArmed` | `DispatchArmedDurable` |
| `AcquireResources` | `LeaseGranted` / `LeaseDenied` |
| `RevalidateGrant` | `GrantValid` / `GrantRevoked` |
| `SendVerify` | `VerifyDispatchAccepted` / `VerifyDispatchNotSent` / `VerifyDispatchUnknown` |
| `SendMutatingCommand` | `MutationDispatchAccepted` / `MutationDispatchNotSent` / `MutationDispatchUnknown` (**all post-arm failures require reconciliation**) |
| `VerifyEvidence` | `EvidenceAccepted` / `EvidenceRejected` |
| `CommitDesiredRegistryAndJournal` | `MetadataDurable(Committed)` / `MetadataFailed` |
| `CommitNoChangeAndJournal` | `MetadataDurable(NoChange)` / `MetadataFailed` |
| `ReleaseResources` | `CleanupConfirmed` / `ResourceUncertain` |
| `DeliverOutcome` | `OwnerDeliveryRecorded` / `OwnerDisconnected` |

Engine never synthesizes a receipt for an I/O operation. Every input carries current op ID, device epoch and worker instance when applicable. Effects are idempotent **only where specified**: e.g. `PublishProgress` may coalesce; `SendMutatingCommand` is **not retryable**.

## Replay and deterministic test vectors

Replay uses persisted state/receipts to rebuild decision state, not to infer real hardware state. Incomplete mutation after `DispatchArmed` enters `Reconciling` and holds the affected enrollment scope locked. Test fixtures must include: crash before `IntentDurable`, after `IntentDurable`, after `DispatchArmed`, after worker response, after Registry CAS; duplicate/stale terminal; revoke during proof check; device epoch change; journal corruption.

### Binding clarifications B-01/B-02 (v0.6.2)

`Reconciling` never transitions directly to `Terminal`. Verified desired state and verified unchanged pre-state **both** pass through `Committing → Finalizing → Terminal`, with distinct atomic metadata effects. `OperationState` carries a pending terminal mutation outcome (Committed or NoChange), which is not publicly delivered before durable finalize and safe cleanup. `PreStateVerified` demands independently verified *complete* pre-state, including preexisting template during replacement; absence of only a new template is insufficient. Registry unchanged does **not** mean skip metadata transaction: journal/outbox and `MUTATION_NO_CHANGE` must be persisted atomically; scope lock remains until safe cleanup and `MUTATION_COMPLETED` with a durable `terminal_outcome`.

`MetadataFailed` after `DispatchArmed` **always** prevents success and triggers `Reconciling`/quarantine, including an ambiguous DB commit receipt. A failed storage write can prevent persisting `NEEDS_RECONCILIATION`; then mark in-memory storage unavailable and refuse operations, recover by reading durable arm/outbox state once storage returns. Never treat a lost metadata ACK as proof CAS did not commit. Recovery may detect Registry already committed but must validate it before finalizing; no repeat hardware mutation.

Verification has **no mutation `DispatchArmed`**; `SendFailedBeforeArm` is removed as a semantic input. `VerifyDispatchNotSent` is accepted only with a validated effect-runner receipt proving no command was dispatched. Transport send/ACK ambiguity is `VerifyDispatchUnknown`: no accepted factor may be delivered, and resource release awaits verified quiescence. Internal failure is typed (`DispatchNotSent` or `DispatchUnknown`); public mapping can be `Unavailable` for a transport/device outage, never `NotMatched`. See [27](27-v062-engine-conflict-resolutions.md).

### v0.6.3 operation classification and dispatch receipts

`decide()` routes solely through the `OperationBody` enum; `is_mutation_request(state)` is prohibited. An incompatible domain input (including Verify dispatch receipt in Enrollment/Removal) returns `InvalidInputForOperation` without effects or transition increment. `SendVerify` and `SendMutatingCommand` have disjoint receipt classes; generic `SendAccepted` is deprecated and cannot be used for routing. Exact semantics and acceptance cases: [28](28-v063-operation-discriminant-and-send.md).

### v0.6.4 — no generic matching stages

`Running` accepts optional semantic progress; there is **no mandatory capture, feature extraction, scoring or matching phase in Engine**. `ProviderMatched` is a validated provider observation only after authorized enrollment-scope validation in Runtime; Evidence is assessed separately. Never implement a Core matcher or template algorithm. See [29](29-v064-provider-owned-matching.md).

### v0.6.5 enrollment authorization sub-phases

`Enrollment` (only) has pre-mutating `AwaitingChallenge` and `AwaitingCredentialAuthorization` subphases when capabilities specify HAT. They are deterministic and accept trusted `ChallengePrepared`/`CredentialAuthorized`/failure observations. They are not provider capture/matching phases; no HAT bytes or challenge signing occurs in Engine. Only after trusted authorization and grant revalidation may the machine request `PersistDispatchArmed`; `SendMutatingCommand` requires durable arm as before. HAT-free providers skip these subphases. Any state/input mismatch is `InvalidInputForOperation` with no effects or transition increment. After arm, timeout/credential loss/worker loss results in reconciliation, not unverified NoChange. See [31](31-v065-enrollment-authorization.md).
