# Biometric Platform v0.6.6 — implementation contract pack

**Статус:** нормативный **baseline проекта для реализации**, предложен на базе v0.5; не объявляет опубликованный стандарт или аппаратно проверенную систему. Дата: 10.11.2026. Дополнение v0.6.1: устранение четырёх обнаруженных неоднозначностей. **v0.6.2: однозначные переходы Engine после reconciliation, MetadataFailed, verification dispatch failures; устойчивое terminal_outcome. v0.6.3: строгий `OperationBody` discriminant и несовместимые send receipts по автоматам.** Спецификация предназначена для исполнителя, который **не должен принимать архитектурные решения самостоятельно**.

## Порядок авторитетности

1. В первую очередь [34-v066-enrollment-command-projection.md](34-v066-enrollment-command-projection.md), затем [30-v065-audit-and-authority.md](30-v065-audit-and-authority.md), [31-v065-enrollment-authorization.md](31-v065-enrollment-authorization.md), [32-v065-bulk-command-buffer.md](32-v065-bulk-command-buffer.md), [33-v065-durable-mutation-plan.md](33-v065-durable-mutation-plan.md) и актуальные `contracts/proto`, затем [28-v063-operation-discriminant-and-send.md](28-v063-operation-discriminant-and-send.md), затем [27-v062-engine-conflict-resolutions.md](27-v062-engine-conflict-resolutions.md), затем [25-v061-conflict-resolutions.md](25-v061-conflict-resolutions.md), [26-mediated-broker-v1.md](26-mediated-broker-v1.md), обновлённые документы `engineering/implementation-v06/` и исходные схемы `contracts/proto/bio/` имеют приоритет над иллюстрациями v0.5 при расхождении. Приоритет касается **проектного baseline**, не фактов об устройствах.
2. Документы `engineering/rust/` v0.5 — декомпозиция и аргументация; `protocols/` и `architecture/` — общие требования.
3. `reference/` — исторические исследовательские материалы GXFP/Goodix/Veles, **не** нормативные контракты продукта.
4. Любая неопределённость аппаратного API или безопасности — **STOP / ADR**, а не допущение исполнителя.

## Закреплённые здесь решения

- Rust workspace: `biometric-core` → `biometric-engine`; отдельно `biometric-persistence`, `biometric-evidence`, `biometric-runtime`, `biometric-protocol`, `biometric-provider-sdk`, `biometric-linux`, `biometric-linux-ipc`, приложения. Нет обратных зависимостей.
- Core/Engine — чистые детерминированные Rust-библиотеки. Engine реализует `decide(state, input) -> Decision`; Runtime выполняет эффекты, возвращает наблюдения.
- Внутри Runtime один последовательный обработчик на операцию, ограниченные mailboxes, отдельные супервизоры оборудования. Для первой реализации допускается Tokio, **не** распространять Tokio в Core/Engine или межъязыковой ABI.
- Registry, MutationJournal и outbox в **одной** транзакционной метадата-БД; baseline — redb. Template Storage независимо и может принадлежать trustlet.
- Изменяющая команда перед отправкой проходит **устойчивый `DispatchArmed`**. После него обрыв означает `NeedsReconciliation`, пока независимая сверка не докажет обратное. Не отправлять мутацию повторно только из-за потери ACK.
- Провайдер — **отдельный устанавливаемый процесс** с `bio.provider.v1`; любой язык; Rust SDK необязателен. Схемы `.proto` — первичный wire-контракт. Linux transport baseline: `AF_UNIX/SOCK_SEQPACKET`, raw Protobuf packet + ancillary FD, без Rust ABI.
- Идентификатор операции и публичная ссылка на grant не являются bearer-capabilities; полномочия устанавливаются системным проверяющим на каждой критической границе.
- `Matched` провайдера не равно `AuthenticationSucceeded` и не подтверждает аппаратную защиту. Hardware token передаётся только подходящему независимому проверяющему.
- Core/Runtime не импортируют Goodix/GXFP/QTEE/libfprint/Veles. `libfprint` — самостоятельный C/GLib worker, `fprintd` — независимый клиентский адаптер.
- В Veles используется существующий владелец профиля/сессии/Поводник/Явь и Uzel; **никаких** прямых зависимостей в Core.

## Точные документы

| Документ | Что исполнитель получает |
|---|---|
| [01-lock](01-decisions-and-change-control.md) | Неизменяемые границы, правила STOP/ADR |
| [02-workspace](02-crates-and-modules.md) | Физическое дерево и owner каждого модуля |
| [03-domain](03-domain-types.md) | Типы, диапазоны, конструкторы, invariants |
| [04-engine](04-pure-engine.md) | Входы, переходы, эффекты и правила replay |
| [05-runtime](05-runtime-actors.md) | Actors, mailbox, cancel, cleanup, порядок блокировок |
| [06-provider](06-provider-host-and-wire.md) | Handshake, команды, ID, FD, процесс worker |
| [07-client](07-public-client-contract.md) | Public API, PAM и внешняя авторизация |
| [08-auth](08-identity-authority.md) | Субъекты, полномочия, отзыв, доверенные источники |
| [09-resource](09-device-and-broker.md) | Discovery, leases, broker, безопасность FD |
| [10-store](10-persistence-and-recovery.md) | Таблицы БД, атомарные изменения и восстановление |
| [11-evidence](11-evidence-and-assurance.md) | Matching, proof, verifier, guarantees |
| [12-provider-packages](12-package-and-update.md) | Manifest, независимая установка, update/rollback |
| [13-bounds](13-limits-errors-and-observability.md) | Численные пределы и политика отказов |
| [14-integration](14-provider-integration-contracts.md) | GXFP, Goodix, libfprint, Nord4, Veles |
| [15-test](15-conformance-matrix.md) | Проверяемые сценарии, negative/fault cases |
| [16-tasks](16-implementation-workorders.md) | Пошаговое задание для менее сильной модели |
| [17-delta](17-delta-and-open-evidence.md) | Что изменилось относительно v0.5 и где запрещено гадать |
| [18-review](18-review-gates.md) | Формальные критерии приёмки и контроля изменений |
| [19-traces](19-normative-traces.md) | Сквозные сценарии с порядком сообщений |
| [20-wire-validator](20-protobuf-wire-validation.md) | Точные правила парсинга, framing и проверок |
| [21-ports](21-internal-port-signatures.md) | Внутренние Rust traits, владение и типы receipts |
| [22-actors](22-actor-messages.md) | Типы сообщений акторов и приоритет control |
| [23-codec](23-storage-codec-and-index.md) | Stable bytes для ключей и записей redb |
| [24-ids-templates](24-package-identity-and-templates.md) | Пакетная идентичность и атомарное хранилище ciphertext |

| [25-review resolutions](25-v061-conflict-resolutions.md) | Четыре окончательных решения по замечаниям модели-исполнителя |
| [26-mediated broker](26-mediated-broker-v1.md) | Семантика FD_ROLE_MEDIATED_SERVICE и `bio.broker.v1` |
| [27-engine conflict resolutions](27-v062-engine-conflict-resolutions.md) | B-01/B-02: подтверждённое состояние, metadata commit, storage loss, verify dispatch |

**Wire schemas:** [common.proto](../../contracts/proto/bio/common/v1/common.proto), [provider.proto](../../contracts/proto/bio/provider/v1/provider.proto), [client.proto](../../contracts/proto/bio/client/v1/client.proto), [storage.proto](../../contracts/proto/bio/storage/v1/storage.proto), [broker.proto](../../contracts/proto/bio/broker/v1/broker.proto). Эти файлы описывают контракт baseline v1, но их совместимость должна быть проверена `protoc` перед публикацией внешнего ABI; **не объявлять schema freeze до такого прогона**.

## Правило для coding agent

Действие по умолчанию: **реализовать точно по документу**. Если предлагаемая реализация требует альтернативного типа/состояния/протокола/хранилища/привилегии, остановить изменение, вывести `ARCHITECTURE_BLOCKER` с местом, конфликтом и минимальными вариантами, и не писать новый архитектурный код до решения. Hardware-specific неизвестное также является blocker. Не заменять ошибку/отказ на молчаливый fallback.

## v0.6.3 — обязательная поправка к Engine

Начинать работу с [28-v063-operation-discriminant-and-send.md](28-v063-operation-discriminant-and-send.md). В `OperationState` выбор машины только через `OperationBody`, а не `mutation.is_some()`. Результаты `SendVerify` и `SendMutatingCommand` не взаимозаменяемы. Для `Enroll(replace)` независимая сверка сравнивает полные pre/desired состояния, частичный исход всегда Indeterminate. Портативный persisted encoding полных pre/desired отсутствовал в v0.6.3; для v0.6.5 установлен canonical logical plan v2 в [33](33-v065-durable-mutation-plan.md). Независимый hardware witness по-прежнему обязателен.

## v0.6.4 provider-owned matching correction

Read [29-v064-provider-owned-matching.md](29-v064-provider-owned-matching.md) before W01…W14. The provider-owned matching rule dates to minor 1; CURRENT v0.6.5 requires Provider wire minor **2**. This overrides all statements implying host-matching is a platform baseline. Vault-backed off-device template storage remains optional and its mediated vault protocol is a separate blocker/ADR; no generic matching, capture or scoring inside Core/Runtime.

## v0.6.5 — normative correction set (read first)

| Source | Scope |
|---|---|
| [30-v065-audit-and-authority](30-v065-audit-and-authority.md) | Issue matrix and precedence |
| [31-v065-enrollment-authorization](31-v065-enrollment-authorization.md) | B-10: secure challenge/HAT via trusted authority and broker |
| [32-v065-bulk-command-buffer](32-v065-bulk-command-buffer.md) | B-11…13: broker minor 1 sealed-memfd, owned DMA lifetime |
| [33-v065-durable-mutation-plan](33-v065-durable-mutation-plan.md) | Immutable logical MutationPlan, stored schema 2, recovery |
| [27-enrollment-challenge-gap](27-enrollment-challenge-gap.md) | Reconstructed missing issue note; NOT original text |

Provider protocol minor >=2 for active operations; broker external body minor >=1; v2 storage for newly written records. Scoped removal always includes `EnrollmentBinding`. `QueryMutationResult` alone is never a trusted physical witness. No raw HAT, central matcher, generic raw QSEE, or auto-retry of an armed mutation. Hardware evidence gates remain open where specified.

## v0.6.6 — mandatory first read for implementers

**Read [34-v066-enrollment-command-projection.md](34-v066-enrollment-command-projection.md) before implementing `MutationChange::Enrollment`, `CommandPlan`, Registry binding resolution, or StartEnrollment.** It resolves B-14: Runtime explicitly projects a validated old binding for REPLACE; CREATE/REPLACE are distinct variants, not two absent nullable fields. Current provider protocol **minor >=3**; storage new records **schema v3**, including custody and exact selected old target. Earlier minor 2/schema 2 values are historical. Reconcile and hardware-evidence gates remain as specified in 30–33.
