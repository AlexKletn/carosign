# 10. Durable metadata, outbox, reconciliation and transactional boundaries

**Baseline:** single redb metadata database (Registry + MutationJournal + Command Outbox), managed by `biometric-persistence`; `template store` remains separate and may live in TA/RPMB or encrypted provider storage. No ACID transaction spans a TA, another process, or external filesystem. Do not implement a cross-hardware rollback fantasy.

## Tables, keys and values

| Table (schema v1) | Key | Value | Owner |
|---|---|---|---|
| `meta` | static enum key | schema revision, migration status, installation identity | persistence |
| `authenticators` | AuthenticatorId(16) | provider binding, device identity fingerprint, epoch, availability | registry |
| `enrollments` | EnrollmentId(16) | SubjectRef, AuthenticatorId, generation, label, opaque provider ref, state | registry |
| `enrollment_index` | `(AuthorityId,SubjectId,AuthenticatorId,EnrollmentId)` | EnrollmentId | registry |
| `mutations` | MutationId(16) | target, expected generation, phase, recovery reference, checksum | journal |
| `mutation_scope_lock` | `(AuthorityId,SubjectId,AuthenticatorId)` | MutationId | journal |
| `effect_outbox` | `(OperationId,TransitionIndex,EffectPosition)` | effect kind, armed/observed phase, command id | effect runner |
| `idempotency` | `(CallerBindingHash,IdempotencyKey)` | request digest, op/mutation ID, retention | runtime |
| `provider_state` | `(PackageId,AuthenticatorId)` | state format, opaque references, migration status | registry |
| `packages` | package name (reverse-DNS, canonical ASCII) | assigned PackageId/ProviderId + installed state | provider manager |
| `template_blobs` | `EnrollmentId[16] || generation(u64 BE)[8]` | `StoredValue.template_blob`; encrypted blob plus **mirrored** EnrollmentId/generation, both REQUIRED to equal the key | template repository |

Keys are fixed-endian canonical bytes. Value encoding uses a **separate versioned storage schema**; do not serialize raw Rust struct layout or use unversioned bincode as the durable contract. Baseline durable value representation: protobuf messages in internal `schema_version=1` envelope with checksums and **bounded** lengths; metadata protection/rollback assurance comes separately from trust anchor, not CRC. Changes in storage schemas require explicit migration and journal recovery plan.

## Write transaction API

```rust
pub trait MetadataStore: Send + Sync {
    fn begin_read(&self) -> Result<ReadTx<'_>, StorageError>;
    fn begin_write(&self) -> Result<WriteTx<'_>, StorageError>;
}
```

`ReadTx`/`WriteTx` are **internal types** with no `async fn` and may not cross `.await`. At most one write transaction per mutation step. A successful returned `DurableReceipt` means the committed data met configured durability guarantees of the backend. Do not dispatch mutating hardware commands on `Ok` from a merely buffered/non-durable write. If backend cannot establish durable commit under requested policy → refuse mutation; do not silently downgrade.

## Mutation boundaries and exact protocol

1. `prepare`: transaction inserts MutationRecord(`Prepared`), scope lock, idempotency record; commit durably; no side effect on hardware before success.
2. Acquire lease and revalidate management grant. If denied, record `NoChange` and release scope lock (after proving no dispatch).
3. `arm`: transaction switches mutation to `DispatchArmed`, creates outbox record `(MutationId,CommandId,OperationId,scope,epoch,worker_instance)`, commits **durably**. Only then side-effect `SendMutatingCommand` is permitted.
4. Send exactly once from that in-memory active operation. Do **not** automatically replay `DispatchArmed` record on startup; it may have already executed hardware mutation.
5. Observe outcome. `ProviderCompleted` records observation; if provider or protocol requires separate state verification, execute safe `QueryMutationState` and validate independent result.
6. `commit`: after observed or independently verified outcome, execute **one of two fixed atomic transactions**. `CommitDesiredRegistryAndJournal`: apply desired enrollment/index change with CAS, record `MUTATION_REGISTRY_COMMITTED` and outbox status. `CommitNoChangeAndJournal`: make **no enrollment/index changes**, but atomically record verified pre-state, mutation `MUTATION_NO_CHANGE` and outbox outcome. Both retain the scope lock, recheck expected enrollment generation under the scope lock, and persist result evidence/provenance. A mismatched CAS after device-side change returns to reconciliation, never overwrites a newer registration. This applies equally after `Reconciling`.
7. `finish`: after confirmed resource quiescence, durably mark `MUTATION_COMPLETED` with `terminal_outcome=COMMITTED|NO_CHANGE` and release scope lock **in one metadata transaction**. Notify only after confirmed durability. Failure to persist finalization leaves scope blocked for recovery, never a fabricated terminal result.

**Crash windows:**

| Window | Recovery |
|---|---|
| Before step 1 durable | no mutation started; safe to refuse |
| `Prepared`, no `DispatchArmed` | confirmed no dispatch; safe no-change cleanup |
| After `DispatchArmed`, before/after IPC send | treat as `NeedsReconciliation` regardless of send ACK |
| After provider success, before metadata CAS | query actual state, then reconcile registry |
| After Registry CAS, before journal Completed | verify current binding and completion, close pending journal |
| During removal | same as enrollment; success of delete != proof of physical secure erase |

No re-execution of `Enroll/Remove` when operation already armed. Even read-only query must be confirmed side-effect free for the specific backend. If independent check unavailable, affected scope stays blocked and admin recovery is required.

## Reconciliation authority

`ReconciliationVerifier` must verify **actual** state using source independent enough from the lost worker event to satisfy provider-specific risk policy. For software-owned storage, atomic blob state+version may be sufficient; for TA-owned storage, query semantics must be established empirically. `Unknown`, malformed reply, changed device identity or epoch → never infer success. If actor/grant died, recovery continues as *maintenance*, not new user-authorized mutation, and must not reveal a result to unauthorized observer.

## Template custody

- Optional platform-managed vault **when explicitly requested by a provider**: encrypted `ProtectedTemplateRecord` in `template_blobs` **inside the same redb database**, supporting atomic ciphertext+Registry CAS+journal metadata commit when the provider-specific write/staging contract is established. `format_id`,`format_version`,`authenticator_id`,`subject`,`enrollment_id`,`generation` are authenticated as AAD; key through `KeyProvider`; plaintext exists only in restricted provider storage adapter, not in Registry or IPC. Template-record maximum 8 MiB, metadata-record maximum 64 KiB. An alternative external blob store requires separate accepted ADR with crash-safe staging protocol; **implementation agent must not invent it**.
- Provider-managed: only bounded `OpaqueEnrollmentRef` in Registry; TA owns templates. No attempt to open/export absent capabilities.
- Changing/removing provider packages preserves registry and blobs; uninstall never deletes them by default.
- Encryption at rest protects confidentiality/integrity under key custody assumptions; does **not** imply rollback prevention or resistance to local root on unverified boot.

## Recovery boot gate

Before public listener readiness: validate schema and DB integrity, scan `mutations`/`outbox`, lock uncertain scopes, then start workers for safe-query reconciliation only. Corrupt existing store is **not** reset as empty. Unknown state exposed as degraded/unavailable. No new mutation on blocked scope until trusted verifier clears it; normal operations on independent unaffected scopes may proceed.

## Migration

Storage schema upgrade is itself journaled (`MigrationPending → Staged → Committed`), with backups/rollback plan and crash recovery; not executed while provider mutation active. Provider package format migration independent of central schema; incompatible template format must fail activation or require explicit migration, never reinterpret bytes.

### Recovery without independently verifiable TA query (v0.6.1)

For Goodix/TB371FC no safe independent TA-state query is established in the supplied research. Missing capability => `QUERY_UNSUPPORTED`; an attempted non-conclusive safe query => `QUERY_UNKNOWN`. Both persist `NeedsReconciliation`, retain scope lock and **prevent using affected registration for verification**. Manager can keep unrelated scopes alive, but not infer hardware state from worker health. Unblock only after verified hardware-state evidence, verified destructive reprovision/clear supported by device and independent verification, or permanently disable/decommission the authenticator without falsely reporting restored state. Admin consent permits destructive remediation but **is not** state evidence. No known safe remediation => keep blocked; execution agent stops at `ARCHITECTURE_BLOCKER` for Goodix recovery. See [14](14-provider-integration-contracts.md) and [25](25-v061-conflict-resolutions.md).

### Reconciliation/metadata failures v0.6.2 — no implicit alternatives

A trusted `ReconciliationVerdict` has three cases: verified post-state → `Committing` with desired Registry CAS; verified *complete* original pre-state → `Committing` with metadata-only NoChange commit; indeterminate → remain `Reconciling` with scope lock. No `Reconciling → Terminal`. For `Remove`, verified **absence** of target is post-state (Committed), while verified preservation of target is pre-state (NoChange). For `Enroll`, verified desired registration is post-state (Committed), while verified untouched original state is pre-state (NoChange). Mismatched identity, generation, incomplete replacement or untrusted query result is neither.

After durable `DispatchArmed`, `MetadataFailed` is an uncertain metadata commit: engine enters `Reconciling`, blocks affected scope and may not resend device mutation. If DB is unavailable and `mark_uncertain` fails, report local `StorageUnavailable` without claiming durable repair, block any authorization on affected scope and inhibit service readiness as required. Once storage is accessible, read **actual durable state** (possibly `REGISTRY_COMMITTED` or `MUTATION_NO_CHANGE` from a commit whose ACK was lost), validate CAS/receipt against independently checked hardware as needed, and finalize without repeating device command. If underlying record corrupted, fail closed.

Stored `MUTATION_COMPLETED` must carry an explicit `terminal_outcome` distinguishing `COMMITTED` and `NO_CHANGE`; `MUTATION_NO_CHANGE` is an **intermediate persisted outcome awaiting cleanup**, not sufficient by itself for unlocked terminal state. Existing v0.6.1 durable schema was a draft, not a shipped frozen format; the new field is reflected in `storage.proto`. Existing deployed data, if any, requires an explicit migration rather than silently defaulting to success. See [27](27-v062-engine-conflict-resolutions.md).

### v0.6.3: immutable reconciliation context after process recovery

Engine `OperationBody::{Enrollment,Removal}` requires validated mutation plan state with the full original/precondition and target/desired postcondition as defined in [28](28-v063-operation-discriminant-and-send.md). `MutationRecord.kind` is a storage consistency check, not a runtime machine selector. Existing `MutationRecord.expected_generation`/`target_enrollment` **alone do not establish complete hardware pre-/post-state**, notably for `Enroll(replace)`. If a trusted comparison context is unavailable after restart, only `Indeterminate` is permitted and the affected scope stays blocked. The exact normative on-disk encoding for a full portable plan is **not established in v0.6.3**; an implementation that must persist/recover such a plan raises `ARCHITECTURE_BLOCKER` instead of inventing a schema or using a partial proxy.

### v0.6.4 — platform vault is optional; not a matching backend

The `template_blobs` redb table and `ProtectedTemplateRecord` define an **optional encrypted template vault for providers requesting external storage**. Although detailed here, this is not a mandatory baseline for every authenticator: TA/chip/provider-managed enrollment requires **no** `template_blobs` value. Runtime metadata Registry and mutation journal are mandatory; software templates, their serialization and matching are never interpreted by Core/Engine. Any service giving a worker access to vault blobs must be explicitly scoped per enrollment/subject/authenticator/generation and needs a separately approved vault protocol + durable staging contract before implementation. `CUSTODY_PLATFORM_MANAGED` identifies use of that service, **not host matching**; `CUSTODY_PROVIDER_MANAGED` means no platform vault required. See [29](29-v064-provider-owned-matching.md).

### v0.6.5: durable plan v2 is mandatory for new mutations

`MutationRecord.plan` is now a required immutable `MutationPlanRecord` persisted with `MUTATION_PREPARED`, with canonical logical binding snapshots, prospective enrollment ID/generation and desired transition predicate. `StoredValue.schema_version=2`; migration/nonterminal v1 rules and the exact digest are in [33](33-v065-durable-mutation-plan.md). Previous text identifying this as an *unspecified* on-disk format describes v0.6.3 history only. Plan recovery cannot replace an independent physical hardware witness; Goodix without safe query remains blocked. Do not serialize HAT/token, mutable DMA buffers or provider raw template into the plan.

### v0.6.6 durable enrollment projection amendment

Earlier plan-v2 wording is historic. All newly prepared mutation records are `StoredValue.schema_version=3`, with typed custody kind and `old_target` included in the canonical digest. Runtime's checked `CommandPlan` is a **volatile derived projection**, not stored as second source of truth. It must be constructed only under the matching scope lock from the immutable plan and verified full Registry snapshot. After durable arm, no automatic rebuild/resend is allowed. See [34](34-v066-enrollment-command-projection.md).
