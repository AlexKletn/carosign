# 07. Runtime, scheduler, процессные состояния

## Три независимых state machine

**Worker:** `Installed → Selected → Starting → Negotiating → Binding → Ready → Draining/Recovering/Quarantined`.

**Device:** `Available → Reserved → Active → Quiescing → Available`; fault → `Uncertain → Recovering → Available/Unavailable`.

**Operation:** `Created → Authorizing → Queued → Acquiring → Running → Finalizing → Terminal`, плюс `CancellationRequested`. Перемешивать их в общий enum — ошибка.

## Actor модели

На одну аппаратную session — один actor с mailbox команд и отдельным control path для cancel/liveness. Блокирующий ioctl/TEE выполняется вне control task; request cancel должен доставляться даже при зависшем аппаратном вызове. Future cancellation не гарантирует прерывания kernel call.

## Планирование

Планировщик хранит bounded queues для каждого `ResourceSet`, выделяет lease атомарно и ограничивает один активный несовместимый доступ. Не делать предположение «один AuthenticatorId = один независимый датчик»: QSEE listener/TA и два логических аутентификатора могут делить ресурсы.

Предлагаемая политика: системный auth request имеет приоритет над диагностикой, но даже привилегированный клиент не получает бесконечную неотзываемую аренду. Starvation prevention и max wait — отдельно задаваемая политика ОС.

## Наблюдение и cancellation

Supervisor отслеживает process exit (на Linux предпочтительно pidfd), heartbeat отдельно от progress deadline, IPC closures, resource lease revocation. `WorkerAlive` != `DeviceHealthy`. После crash verification fail-closed; mutation journal → reconcile. При многократных crash — capped exponential backoff, затем Quarantined.

## Reboot

Процессные и UI grants не переживают reboot. Persistent MutationJournal открывается до активации конфликтующих enroll/remove. DeviceEpoch сбрасывается/меняется; ранее созданные request tokens и verification contexts инвалидируются. При unavailable provider registry остаётся, помечаясь недоступным.

## Композиция

В Linux может быть один основной демон + независимые providers; broker выделяется отдельно только при реальных требованиях безопасности. В Veles Runtime может размещаться в системной ячейке; scheduler/leases интегрируются с системными владельцами ресурсов.
