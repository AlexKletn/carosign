# Biometric Platform — архитектурный пакет v0.6.5

**Статус:** проектная спецификация. **v0.6.5:** challenge/HAT enrollment, broker bulk command bodies, durable MutationPlan v2 и исправление scoped removal. **v0.6.4:** provider-owned matching для host/MoC/TEE, обязательные enrollment bindings в provider wire minor 1; **v0.6.3:** state machine discriminant и disjoint send receipts. **v0.6.2:** зафиксированы переходы B-01/B-02 и устойчивый terminal outcome. **v0.6.1:** разрешены четыре замечания к контрактам хранения, FD, Goodix recovery и SubjectRef. **v0.6:** детализированные нормативные контракты для реализации; внешние ABI не объявлены окончательно замороженными до компиляции и conformance. **Дата:** 11 ноября 2026.

## Начать здесь

**[Implementation contract pack v0.6.5](engineering/implementation-v06/README.md)** — приоритетный материал для модели-исполнителя. Точное дерево Rust crates/modules, типы, state machines, runtime actors, ownership, redb journal/outbox, Linux IPC и независимый Provider Protocol. В `contracts/proto/bio` находятся схемы common/provider/client/storage и новый broker для `FD_ROLE_MEDIATED_SERVICE`. Первым делом прочитай [audit v0.6.5](engineering/implementation-v06/30-v065-audit-and-authority.md), [B-10 / enrollment challenge](engineering/implementation-v06/31-v065-enrollment-authorization.md), [B-11…B-13 / bulk buffer](engineering/implementation-v06/32-v065-bulk-command-buffer.md), [durable plan](engineering/implementation-v06/33-v065-durable-mutation-plan.md), затем [D-01…D-08 v0.6.4](engineering/implementation-v06/29-v064-provider-owned-matching.md), затем [C-04/C-05/C-06 v0.6.3](engineering/implementation-v06/28-v063-operation-discriminant-and-send.md), затем [B-01/B-02 v0.6.2](engineering/implementation-v06/27-v062-engine-conflict-resolutions.md), затем [review v0.6.1](engineering/implementation-v06/25-v061-conflict-resolutions.md).

Для передачи другой модели готово [краткое задание исполнителю](IMPLEMENTATION_AGENT_BRIEF.md).

Все документы v0.5 и первичные исследовательские материалы сохранены ниже как контекст. При расхождении проектных предложений v0.5 и v0.6 исполнитель следует v0.6; отсутствие аппаратных свидетельств не исправляется домыслом.

---

# Архитектурные материалы v0.5 (сохранены)

**Статус:** проектная спецификация (`Draft`), не реализованный продукт и не окончательно утверждённый стандарт.  
**Дата сборки:** 10 ноября 2026. **Обновление v0.5:** Rust crate/module decomposition.  
**Основной язык реализации платформы:** Rust. **Язык реализации провайдеров:** любой, поддерживающий `bio.provider.v1`.

## Цель

Создать независимую биометрическую платформу, устанавливаемую в обычный Linux, с раздельно устанавливаемыми аппаратными провайдерами. Платформа может быть встроена в VelesOS через адаптеры, не становясь частью Veles и не завися от её IPC, менеджера сессий, Поводника или «Яви». Поддержка libfprint реализуется как отдельный провайдер, а fprintd-совместимость — как отдельный клиентский API-адаптер.

**Основная граница:** платформа управляет биометрическими аутентификаторами, регистрациями, операциями и результатами; политику входа, авторизации действий и доступ к ключам определяет внешняя система.

## Как читать

1. [Статус решений и источники](architecture/00-status-and-sources.md)
2. [Цели, границы и инварианты](architecture/01-product-and-principles.md)
3. [Компоненты и владельцы](architecture/02-components-and-topology.md)
4. [Доменная модель](architecture/03-domain-model.md)
5. [Provider Package и установка](architecture/04-provider-package.md)
6. [Обнаружение, выбор и привязка](architecture/05-device-discovery.md)
7. [Транспорт и конверты](protocols/00-transport.md)
8. [Протокол провайдера](protocols/01-provider-wire-v1.md)
9. [Публичный протокол](protocols/02-client-wire-v1.md)
10. [Полномочия и ресурсы](protocols/03-authority-and-resources.md)
11. [Evidence и trust](protocols/04-evidence-and-trust.md)
12. [Операции и восстановление](protocols/05-operations-and-recovery.md)
13. [Хранение](architecture/06-persistence.md)
14. [Планировщик и жизненный цикл](architecture/07-runtime-lifecycle.md)
15. [Модель безопасности](architecture/08-security.md)
16. [Linux](platforms/linux.md) · [Veles](platforms/veles.md)
17. [libfprint](providers/libfprint-bridge.md) · [GXFP](providers/gxfp5130.md) · [Goodix](providers/goodix-qsee.md) · [Nord 4](providers/nord4-qtee.md)
18. [Операционная эксплуатация](engineering/operations-and-upgrades.md) · [Workspace](engineering/workspace.md) · [План реализации](engineering/roadmap.md) · [Conformance](engineering/conformance.md)
19. [Сценарии обмена](protocols/06-end-to-end-examples.md) · [ADR](engineering/decisions.md) · [Открытые вопросы](engineering/open-questions.md) · [Глоссарий](engineering/glossary.md)

## Детализация Rust-проектов v0.5

См. **[engineering/rust/README.md](engineering/rust/README.md)**: 25 проектных документов с деревьями внутренних модулей, контрактами, исполнением операций, зависимостями и сценарием реализации. Это проектируемая структура, **не существующий исходный код**. Для модульности провайдеров язык реализации остаётся свободным; отдельно рассмотрен C/GLib libfprint bridge.

## Степень определённости

- **Зафиксированное направление:** независимый продукт; модульные устанавливаемые аппаратные провайдеры; языковая нейтральность; процессная изоляция; API, не зависящее от Rust ABI; libfprint bridge; Veles как интеграция, не зависимость.
- **Предлагаемый baseline v1 (требует утверждения):** Protobuf; Linux `AF_UNIX/SOCK_SEQPACKET`; конкретные состояния, имена сообщений и требования к журналу.
- **Доказано только в исходных проектах:** отдельные возможности GXFP, Goodix/TB371FC и Nord 4. Они не подтверждают работоспособность собранной здесь новой платформы.

## Важно

Это **пакет проектной документации**, не исходники рабочего демона и не самостоятельный компилируемый набор `.proto`. Встроенные блоки Protobuf и Rust показывают ориентиры для будущих нормативных схем. Числа, пути и названия в примерах помечаются как предложения; аппаратные ID в примерах не следует считать проверенными.

В `reference/` находятся копии предоставленных пользователем документов и актуальные справочные разделы из Goodix-архива. Они **не становятся** нормативной частью этой архитектуры; в случае противоречия см. статусы в `architecture/00-status-and-sources.md`.

## Исправление архитектуры v0.6.4 — сопоставление исключительно у провайдера

Главный нормативный документ: [29 — provider-owned matching](engineering/implementation-v06/29-v064-provider-owned-matching.md). Core/Runtime/Engine **не выполняют** захват, matching, вычисление scores, декодирование шаблонов или выбор алгоритма. Единый IPC поддерживает software, match-on-chip и TEE; `template_blobs` — опциональный vault. Уточнён `provider.proto` minor 1 и проверки привязок, добавлены M-01…M-12. Старые host-oriented формулировки заменены этим контрактом.

## Поправки v0.6.5 — обязательная отправная точка

- [30 — audit, gaps, priority, remaining hardware evidence](engineering/implementation-v06/30-v065-audit-and-authority.md)
- [31 — B-10 challenged enrollment + HAT](engineering/implementation-v06/31-v065-enrollment-authorization.md)
- [32 — B-11…B-13 broker sealed-memfd → trusted module/DMA](engineering/implementation-v06/32-v065-bulk-command-buffer.md)
- [33 — durable MutationPlan v2](engineering/implementation-v06/33-v065-durable-mutation-plan.md)
- [27-enrollment-challenge-gap.md](engineering/implementation-v06/27-enrollment-challenge-gap.md) — **восстановленная заметка**, оригинал отсутствовал в архиве v0.6.4.

Нормативные внешние схемы (`contracts/proto`) изменены: `bio.provider.v1` требует minor **2**, `bio.broker.v1` — minor **1** для внешнего тела, storage persisted `StoredValue.schema_version` — **2** для новых записей. Существующая версия `bio.client.v1` не изменена. Эти изменения проектные, не подтверждают аппаратную реализацию или ABI freeze. Для Goodix реальный успех регистрации и безопасный reconciliation-query не установлен.

## Поправки v0.6.6 — явная модель Create/Replace

Главный нормативный документ: [34 — типизированный CommandPlan и привязка прежней регистрации](engineering/implementation-v06/34-v066-enrollment-command-projection.md). В `MutationChange::Enrollment` запрещена одинаковая пара пустых значений для новой регистрации и замены. Runtime строит `Create(planned_new)` либо `Replace(planned_new, validated_old_binding)` из **одного** неизменяемого `MutationPlan` и проверенной Registry под scope lock. Адаптер не ищет старую регистрацию и не определяет смысл самостоятельно.

Текущие версии **Provider v1.3**, **Broker v1.1**, **StoredValue schema v3**. Добавлен `StartEnrollment.planned_enrollment`, `EnrollmentRecord.binding_kind`, `BindingSnapshot.binding_kind`, `MutationPlanRecord.old_target`. Исторические упоминания Provider v1.2/Storage v2 выше относятся к v0.6.5. Это проектный baseline, не подтверждение сборки/аппаратной безопасности.
